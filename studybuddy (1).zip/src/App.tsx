/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Type } from "@google/genai";
import { 
  LayoutDashboard, 
  BookOpen, 
  FileText, 
  BrainCircuit, 
  Settings,
  Bell,
  Search,
  Plus,
  BookMarked,
  Trophy,
  History,
  ChevronLeft,
  ChevronRight,
  Menu,
  Calendar,
  X,
  Target,
  FolderPlus,
  Tag,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Trash2,
  Moon,
  Sun,
  User,
  Mail,
  BellOff,
  ShieldCheck,
  Cpu,
  Zap,
  Globe
} from 'lucide-react';

// --- Types & Constants ---

type Section = 'dashboard' | 'calendar' | 'subjects' | 'notes' | 'quiz' | 'theory' | 'settings';

interface UserProfile {
  name: string;
  username: string;
  email: string;
  avatarSeed: string;
}

interface AppSettings {
  notifications: boolean;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  studyReminders: boolean;
  aiModel: 'Gemini 1.5' | 'Gemini 2.0' | 'Experimental';
}

interface Subject {
  id: string;
  title: string;
  category: string;
  folder?: string;
  tags: string[];
  details: string;
  createdAt: number;
  goalProgress: number;
}

interface UserStats {
  completedQuizzes: number;
  studyHours: number;
}

interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface Note {
  id: string;
  title: string;
  content: string;
  color: string;
  category: string;
  createdAt: number;
}

// --- Gemini AI Setup ---
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function App() {
  const [activeTab, setActiveTab] = useState<Section>('dashboard');
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('studybuddy_profile');
    return saved ? JSON.parse(saved) : {
      name: 'Alex Study',
      username: 'alex_pro_26',
      email: 'alex.pro@student.edu',
      avatarSeed: 'Alex'
    };
  });

  const [appSettings, setAppSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('studybuddy_settings');
    return saved ? JSON.parse(saved) : {
      notifications: true,
      difficulty: 'Intermediate',
      studyReminders: true,
      aiModel: 'Gemini 2.0'
    };
  });

  const [subjects, setSubjects] = useState<Subject[]>(() => {
    try {
      const saved = localStorage.getItem('studybuddy_subjects');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isAddingSubject, setIsAddingSubject] = useState(false);

  const [notes, setNotes] = useState<Note[]>(() => {
    try {
      const saved = localStorage.getItem('studybuddy_notes');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);

  const [stats, setStats] = useState<UserStats>(() => {
    try {
      const saved = localStorage.getItem('studybuddy_stats');
      return saved ? JSON.parse(saved) : { completedQuizzes: 0, studyHours: 0 };
    } catch {
      return { completedQuizzes: 0, studyHours: 0 };
    }
  });

  useEffect(() => {
    localStorage.setItem('studybuddy_stats', JSON.stringify(stats));
  }, [stats]);

  useEffect(() => {
    localStorage.setItem('studybuddy_notes', JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem('studybuddy_subjects', JSON.stringify(subjects));
  }, [subjects]);

  useEffect(() => {
    localStorage.setItem('studybuddy_profile', JSON.stringify(userProfile));
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem('studybuddy_settings', JSON.stringify(appSettings));
  }, [appSettings]);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'subjects', label: 'Subjects', icon: Target },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'notes', label: 'Notes', icon: FileText },
    { id: 'quiz', label: 'Quiz', icon: BrainCircuit },
    { id: 'theory', label: 'Theory', icon: BookOpen },
    { id: 'settings', label: 'Settings', icon: Settings },
  ] as const;

  const handleAddSubject = (newSubject: Omit<Subject, 'id' | 'createdAt' | 'goalProgress'>) => {
    const subject: Subject = {
      ...newSubject,
      id: crypto.randomUUID(),
      createdAt: Date.now(),
      goalProgress: 0
    };
    setSubjects(prev => [subject, ...prev]);
    setIsAddingSubject(false);
  };

  const deleteSubject = (id: string) => {
    setSubjects(prev => prev.filter(s => s.id !== id));
  };

  const handleAddNote = (newNote: Omit<Note, 'id' | 'createdAt'>) => {
    const note: Note = {
      ...newNote,
      id: crypto.randomUUID(),
      createdAt: Date.now()
    };
    setNotes(prev => [note, ...prev]);
    setIsAddingNote(false);
  };

  const handleUpdateNote = (updatedNote: Note) => {
    setNotes(prev => prev.map(n => n.id === updatedNote.id ? updatedNote : n));
    setEditingNote(null);
  };

  const deleteNote = (id: string) => {
    setNotes(prev => prev.filter(n => n.id !== id));
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView 
          subjects={subjects} 
          onAddSubject={() => setIsAddingSubject(true)} 
          userName={userProfile.name} 
          stats={stats}
        />;
      case 'subjects':
        return <SubjectsView subjects={subjects} onAddSubject={() => setIsAddingSubject(true)} onDeleteSubject={deleteSubject} />;
      case 'calendar':
        return <CalendarView />;
      case 'notes':
        return <NotesView 
          notes={notes} 
          onAddNote={() => setIsAddingNote(true)} 
          onEditNote={setEditingNote} 
          onDeleteNote={deleteNote}
        />;
      case 'quiz':
        return <QuizView 
          subjects={subjects} 
          onQuizComplete={() => setStats(prev => ({ 
            ...prev, 
            completedQuizzes: prev.completedQuizzes + 1,
            studyHours: prev.studyHours + 1 // Add 1 hour per quiz task
          }))} 
        />;
      case 'theory':
        return <TheoryView 
          subjects={subjects} 
          onTheoryComplete={() => setStats(prev => ({ 
            ...prev, 
            studyHours: prev.studyHours + 1 // Add 1 hour per theory mastery task
          }))}
        />;
      case 'settings':
        return <SettingsView 
          profile={userProfile} 
          setProfile={setUserProfile} 
          settings={appSettings} 
          setSettings={setAppSettings}
        />;
      default:
        return <DashboardView 
          subjects={subjects} 
          onAddSubject={() => setIsAddingSubject(true)} 
          userName={userProfile.name} 
          stats={stats}
        />;
    }
  };

  return (
    <div className={`min-h-screen flex text-slate-900 bg-white transition-colors duration-300`}>
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex flex-col w-64 bg-white border-r border-slate-200 p-6 sticky top-0 h-screen">
        <div className="flex items-center gap-3 mb-10 px-2 text-indigo-600">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
            <BrainCircuit size={24} />
          </div>
          <span className="font-display font-bold text-xl tracking-tight text-slate-900">StudyBuddy</span>
        </div>

        <nav className="flex-1 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === item.id 
                  ? 'bg-indigo-50 text-indigo-600 font-medium' 
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="mt-auto p-4 bg-slate-50 rounded-2xl">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Study Goals</p>
          <p className="text-sm font-medium text-slate-700 mb-3">{subjects.length} Subjects Tracked</p>
          <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-indigo-600 h-full transition-all duration-1000 shadow-[0_0_8px_rgba(99,102,241,0.5)]" 
              style={{ width: `${Math.min(subjects.length * 10, 100)}%` }}
            ></div>
          </div>
        </div>
      </aside>

      {/* Mobile Nav Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 lg:hidden"
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-72 bg-white z-50 p-6 lg:hidden"
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
                    <BrainCircuit size={18} />
                  </div>
                  <span className="font-display font-bold text-lg tracking-tight text-slate-900">StudyBuddy</span>
                </div>
                <button onClick={() => setSidebarOpen(false)} className="p-2 text-slate-500">
                  <X size={20} />
                </button>
              </div>

              <nav className="space-y-1">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                      activeTab === item.id 
                        ? 'bg-indigo-50 text-indigo-600 font-medium' 
                        : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <item.icon size={20} />
                    <span>{item.label}</span>
                  </button>
                ))}
              </nav>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto">
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200 px-4 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-lg"
            >
              <Menu size={20} />
            </button>
            <div className="relative hidden sm:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Search resources..." 
                className="pl-10 pr-4 py-2 bg-slate-100 border-none rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 w-64 lg:w-96 transition-all text-slate-900"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 lg:gap-4">
            <div className="flex items-center gap-3 pl-1">
              <div className="hidden sm:block text-right">
                <p className="text-sm font-semibold text-slate-900">{userProfile.name}</p>
                <p className="text-xs text-slate-500">@{userProfile.username}</p>
              </div>
              <img 
                src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${userProfile.avatarSeed}`} 
                alt="Profile" 
                className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </header>

        {/* Content Section */}
        <div className="flex-1 p-4 lg:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Modals & Overlays */}
        <AnimatePresence>
          {isAddingSubject && (
            <SubjectCreatorModal 
              onClose={() => setIsAddingSubject(false)} 
              onSave={handleAddSubject} 
            />
          )}
          {isAddingNote && (
            <NoteModal 
              onClose={() => setIsAddingNote(false)}
              onSave={handleAddNote}
            />
          )}
          {editingNote && (
            <NoteModal 
              note={editingNote}
              onClose={() => setEditingNote(null)}
              onSave={(updated) => handleUpdateNote(updated as Note)}
            />
          )}
        </AnimatePresence>

        {/* Mobile Bottom Navigation */}
        <nav className="lg:hidden fixed bottom-6 left-1/2 -translate-x-1/2 w-[90%] glass-card rounded-full p-2 flex items-center justify-around z-50">
          {navItems.filter(i => i.id !== 'settings').map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`p-3 rounded-full transition-all duration-200 ${
                activeTab === item.id 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200 scale-110' 
                  : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <item.icon size={20} />
            </button>
          ))}
        </nav>
      </main>
    </div>
  );
}

// --- Components ---

function SubjectCreatorModal({ onClose, onSave }: { onClose: () => void, onSave: (s: any) => void }) {
  const [formData, setFormData] = useState({
    title: '',
    category: 'Mathematics',
    folder: '',
    tags: [] as string[],
    details: ''
  });
  const [tagInput, setTagInput] = useState('');

  const categories = ['Mathematics', 'Science', 'History', 'Literature', 'Languages', 'Art', 'Technology'];

  const addTag = () => {
    if (tagInput && !formData.tags.includes(tagInput)) {
      setFormData({ ...formData, tags: [...formData.tags, tagInput] });
      setTagInput('');
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="relative bg-white w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden border border-slate-100"
      >
        <div className="p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h2 className="text-2xl font-display font-bold">New Subject Goal</h2>
              <p className="text-slate-500 text-sm">Define what you want to master next</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-xl text-slate-400"><X size={20} /></button>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Subject Title</label>
              <input 
                type="text" 
                placeholder="e.g. Quantum Physics 101" 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all outline-none text-slate-900"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Category</label>
                <select 
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-900"
                  value={formData.category}
                  onChange={e => setFormData({ ...formData, category: e.target.value })}
                >
                  {categories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Folder</label>
                <div className="relative">
                  <FolderPlus size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="General" 
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-900"
                    value={formData.folder}
                    onChange={e => setFormData({ ...formData, folder: e.target.value })}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Tags</label>
              <div className="flex flex-wrap gap-2 mb-2">
                {formData.tags.map(tag => (
                  <span key={tag} className="inline-flex items-center gap-1 bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold border border-indigo-100">
                    {tag}
                    <button onClick={() => setFormData({ ...formData, tags: formData.tags.filter(t => t !== tag) })}><X size={12} /></button>
                  </span>
                ))}
              </div>
              <div className="relative">
                <Tag size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Press Enter to add tag" 
                  className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-900"
                  value={tagInput}
                  onChange={e => setTagInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && addTag()}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Additional Details</label>
              <textarea 
                placeholder="Specific topics, chapters, or learning goals..." 
                rows={3}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all outline-none resize-none text-slate-900"
                value={formData.details}
                onChange={e => setFormData({ ...formData, details: e.target.value })}
              />
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button 
              onClick={onClose}
              className="flex-1 py-4 text-slate-500 font-bold hover:bg-slate-100 rounded-2xl transition-colors"
            >
              Cancel
            </button>
            <button 
              disabled={!formData.title}
              onClick={() => onSave(formData)}
              className="flex-[2] py-4 bg-indigo-600 text-white font-bold rounded-2xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 disabled:opacity-50 transition-all"
            >
              Save Subject
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function SubjectsView({ subjects, onAddSubject, onDeleteSubject }: { subjects: Subject[], onAddSubject: () => void, onDeleteSubject: (id: string) => void }) {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900">Your Subjects</h1>
          <p className="text-slate-500">Manage your active learning goals</p>
        </div>
        <button 
          onClick={onAddSubject}
          className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-3 rounded-2xl font-bold shadow-lg shadow-indigo-100 hover:scale-105 transition-all"
        >
          <Plus size={20} />
          <span>Add Subject</span>
        </button>
      </div>

      {!subjects.length ? (
        <div className="bg-white border-2 border-dashed border-slate-200 rounded-[32px] p-12 text-center space-y-4">
          <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto text-slate-300">
            <Target size={32} />
          </div>
          <div className="space-y-1">
            <h3 className="text-xl font-bold">No subjects yet</h3>
            <p className="text-slate-500">Start by adding a subject you want to master.</p>
          </div>
          <button onClick={onAddSubject} className="text-indigo-600 font-bold px-6 py-2 rounded-xl hover:bg-indigo-50 transition-colors">Create First Goal</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {subjects.map(subject => (
            <div key={subject.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group">
              <div className="flex items-start justify-between mb-4">
                <div className="bg-indigo-50 text-indigo-600 p-2 rounded-xl">
                  {subject.category === 'Science' ? <BrainCircuit size={24} /> : <BookOpen size={24} />}
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-right">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">{subject.folder || 'General'}</span>
                    <span className="inline-block px-2 py-0.5 bg-slate-50 text-slate-600 rounded text-[10px] font-bold mt-1 uppercase leading-none">{subject.category}</span>
                  </div>
                  <button 
                    onClick={() => onDeleteSubject(subject.id)}
                    className="p-2 text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <h3 className="text-xl font-bold mb-2 line-clamp-1">{subject.title}</h3>
              <p className="text-sm text-slate-500 line-clamp-2 min-h-[40px] mb-4">{subject.details || 'No additional details provided.'}</p>
              
              <div className="flex flex-wrap gap-1.5 mb-6">
                {subject.tags.slice(0, 3).map(tag => (
                  <span key={tag} className="text-[10px] bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-semibold">#{tag}</span>
                ))}
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-400">Mastery</span>
                  <span className="text-indigo-600">{subject.goalProgress}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className="bg-indigo-600 h-full transition-all duration-1000" style={{ width: `${subject.goalProgress}%` }}></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// --- View Components ---

function DashboardView({ subjects, onAddSubject, userName, stats }: { 
  subjects: Subject[], 
  onAddSubject: () => void, 
  userName: string,
  stats: UserStats
}) {
  const dashboardStats = [
    { label: 'Completed Quizzes', value: stats.completedQuizzes.toString(), icon: Trophy, color: 'text-amber-500', bg: 'bg-amber-50' },
    { label: 'Active Goals', value: subjects.length.toString(), icon: Target, color: 'text-indigo-500', bg: 'bg-indigo-50' },
    { label: 'Study Hours', value: `${stats.studyHours}h`, icon: History, color: 'text-emerald-500', bg: 'bg-emerald-50' },
  ];

  return (
    <div className="space-y-8 pb-20 lg:pb-0">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900 tracking-tight">Good afternoon, {userName.split(' ')[0]}!</h1>
          <p className="text-slate-500 mt-1">Ready to solve some problems today?</p>
        </div>
        <button 
          onClick={onAddSubject}
          className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-semibold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
        >
          <Plus size={18} />
          <span>New Goal</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {dashboardStats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm transition-hover hover:border-slate-200">
            <div className={`w-12 h-12 ${stat.bg} ${stat.color} rounded-xl flex items-center justify-center mb-4`}>
              <stat.icon size={24} />
            </div>
            <p className="text-slate-500 text-sm font-medium">{stat.label}</p>
            <p className="text-2xl font-display font-bold text-slate-900 mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Focus Areas */}
        <section className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-display font-bold text-lg">Focus Areas</h2>
            <button className="text-indigo-600 text-sm font-semibold flex items-center gap-1">
              View all <ChevronRight size={16} />
            </button>
          </div>
          <div className="space-y-4">
            {subjects.slice(0, 3).map((s) => (
              <div key={s.id} className="flex items-center gap-4 p-4 rounded-xl border border-slate-50 hover:bg-slate-50 transition-colors cursor-pointer group">
                <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center text-slate-500 group-hover:bg-indigo-100 group-hover:text-indigo-600">
                  <Target size={20} />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold">{s.title}</p>
                  <p className="text-xs text-slate-500">{s.category} • {s.goalProgress}% Mastery</p>
                </div>
                <ChevronRight size={16} className="text-slate-300" />
              </div>
            ))}
            {!subjects.length && (
              <div className="text-center py-8 space-y-3">
                <p className="text-slate-400 text-sm italic">No subjects tracked yet.</p>
                <button onClick={onAddSubject} className="text-indigo-600 text-sm font-bold underline">Add your first goal</button>
              </div>
            )}
          </div>
        </section>

        {/* Deep Study Tip */}
        <section className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display font-bold text-lg">Deep Study Tip</h2>
              <div className="w-8 h-8 bg-indigo-50 rounded-lg flex items-center justify-center text-indigo-600">
                <BrainCircuit size={16} />
              </div>
            </div>
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
              <p className="text-slate-700 font-medium leading-relaxed italic">
                "The best way to master a complex topic is to explain it as if you were teaching a child. Try the Theory section to simplify your concepts!"
              </p>
              <div className="mt-4 flex items-center gap-2">
                <div className="w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center text-[10px] text-white font-bold">AI</div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">StudyBuddy Insight</span>
              </div>
            </div>
          </div>
          <div className="absolute -bottom-12 -right-12 w-48 h-48 bg-indigo-50 rounded-full blur-3xl opacity-50"></div>
        </section>
      </div>
    </div>
  );
}

function CalendarView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();
  
  const monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const today = new Date();
  
  const days = Array.from({ length: daysInMonth(year, month) }, (_, i) => i + 1);
  const emptyDays = Array.from({ length: firstDayOfMonth(year, month) }, (_, i) => i);

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

  const events = [
    { day: 12, title: 'Physics Exam', color: 'bg-rose-500' },
    { day: 15, title: 'Calculus Quiz', color: 'bg-amber-500' },
    { day: 22, title: 'Lab Submission', color: 'bg-indigo-500' },
    { day: today.getDate(), title: 'Study Session', color: 'bg-emerald-500' },
  ];

  return (
    <div className="space-y-6 pb-20 lg:pb-0">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold">Study Schedule</h1>
          <p className="text-slate-500">Keep track of your academic commitments</p>
        </div>
        <div className="flex items-center gap-2 bg-white p-1 rounded-2xl border border-slate-100 shadow-sm">
          <button onClick={prevMonth} className="p-2 hover:bg-slate-50 rounded-xl transition-colors">
            <ChevronLeft size={20} />
          </button>
          <span className="px-4 font-bold text-slate-700 min-w-[140px] text-center">
            {monthNames[month]} {year}
          </span>
          <button onClick={nextMonth} className="p-2 hover:bg-slate-50 rounded-xl transition-colors">
            <ChevronRight size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="grid grid-cols-7 border-b border-slate-100">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="py-4 text-center text-xs font-bold text-slate-400 uppercase tracking-widest">
                  {day}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7">
              {emptyDays.map(i => (
                <div key={`empty-${i}`} className="aspect-square border-r border-b border-slate-50 p-2 opacity-30">
                  <span className="text-sm font-medium text-slate-300"></span>
                </div>
              ))}
              {days.map(day => {
                const isToday = today.getDate() === day && today.getMonth() === month && today.getFullYear() === year;
                const dayEvents = events.filter(e => e.day === day);
                
                return (
                  <div key={day} className={`aspect-square border-r border-b border-slate-50 p-2 relative group cursor-pointer hover:bg-slate-50 transition-colors`}>
                    <span className={`text-sm font-bold inline-flex items-center justify-center w-7 h-7 rounded-lg ${
                      isToday ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-slate-600'
                    }`}>
                      {day}
                    </span>
                    <div className="mt-1 space-y-1">
                      {dayEvents.map((event, idx) => (
                        <div key={idx} className="flex items-center gap-1">
                          <div className={`w-1.5 h-1.5 rounded-full ${event.color}`}></div>
                          <span className="text-[10px] font-medium text-slate-500 truncate hidden sm:block">{event.title}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <h2 className="font-display font-bold text-xl px-2">Upcoming Events</h2>
          <div className="space-y-4">
            {events.sort((a,b) => a.day - b.day).map((event, idx) => (
              <div key={idx} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-start gap-4">
                <div className={`w-10 h-10 rounded-xl ${event.color}/10 flex items-center justify-center shrink-0`}>
                  <div className={`w-2.5 h-2.5 rounded-full ${event.color}`}></div>
                </div>
                <div>
                  <p className="font-bold text-sm">{event.title}</p>
                  <p className="text-xs text-slate-500">{monthNames[month]} {event.day}, {year}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-700 p-6 rounded-3xl text-white">
            <h4 className="font-bold mb-2">Sync with Google</h4>
            <p className="text-xs text-indigo-100 mb-4 opacity-80">Import your class schedule directly from Google Calendar.</p>
            <button className="w-full py-2 bg-white/20 hover:bg-white/30 rounded-xl text-xs font-bold transition-colors backdrop-blur-sm">Connect Now</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function NotesView({ notes, onAddNote, onEditNote, onDeleteNote }: { 
  notes: Note[], 
  onAddNote: () => void, 
  onEditNote: (n: Note) => void,
  onDeleteNote: (id: string) => void
}) {
  const getNoteStyles = (color: string) => {
    switch(color) {
      case 'indigo': return {
        card: 'bg-indigo-50 border-indigo-100',
        title: 'text-indigo-900',
        content: 'text-indigo-800/80',
        badge: 'bg-indigo-100 text-indigo-600',
        footer: 'border-indigo-100/50 text-indigo-500'
      };
      case 'rose': return {
        card: 'bg-rose-50 border-rose-100',
        title: 'text-rose-900',
        content: 'text-rose-800/80',
        badge: 'bg-rose-100 text-rose-600',
        footer: 'border-rose-100/50 text-rose-500'
      };
      case 'amber': return {
        card: 'bg-amber-50 border-amber-100',
        title: 'text-amber-900',
        content: 'text-amber-800/80',
        badge: 'bg-amber-100 text-amber-600',
        footer: 'border-amber-100/50 text-amber-500'
      };
      case 'emerald': return {
        card: 'bg-emerald-50 border-emerald-100',
        title: 'text-emerald-900',
        content: 'text-emerald-800/80',
        badge: 'bg-emerald-100 text-emerald-600',
        footer: 'border-emerald-100/50 text-emerald-500'
      };
      case 'sky': return {
        card: 'bg-sky-50 border-sky-100',
        title: 'text-sky-900',
        content: 'text-sky-800/80',
        badge: 'bg-sky-100 text-sky-600',
        footer: 'border-sky-100/50 text-sky-500'
      };
      case 'violet': return {
        card: 'bg-violet-50 border-violet-100',
        title: 'text-violet-900',
        content: 'text-violet-800/80',
        badge: 'bg-violet-100 text-violet-600',
        footer: 'border-violet-100/50 text-violet-500'
      };
      case 'orange': return {
        card: 'bg-orange-50 border-orange-100',
        title: 'text-orange-900',
        content: 'text-orange-800/80',
        badge: 'bg-orange-100 text-orange-600',
        footer: 'border-orange-100/50 text-orange-500'
      };
      default: return {
        card: 'bg-white border-slate-100',
        title: 'text-slate-900',
        content: 'text-slate-500',
        badge: 'bg-slate-100 text-slate-600',
        footer: 'border-slate-50 text-slate-400'
      };
    }
  };

  return (
    <div className="space-y-6 pb-20 lg:pb-0">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold">My Study Notes</h1>
          <p className="text-slate-500">Capture your thoughts and concepts</p>
        </div>
        <button 
          onClick={onAddNote}
          className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-100 hover:scale-105 transition-all"
        >
          <Plus size={24} />
        </button>
      </div>

      {!notes.length ? (
        <div className="bg-white border-2 border-dashed border-slate-200 rounded-[32px] p-12 text-center space-y-4">
          <BookMarked size={48} className="mx-auto text-slate-300" />
          <p className="text-slate-500 font-medium">Your notebook is empty. Start writing your first note!</p>
          <button onClick={onAddNote} className="text-indigo-600 font-bold underline">Add Note</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {notes.map((note) => {
            const styles = getNoteStyles(note.color);
            return (
              <div 
                key={note.id} 
                onClick={() => onEditNote(note)}
                className={`${styles.card} p-1 rounded-3xl border shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer group relative`}
              >
                <div className="p-5 space-y-4">
                  <div className="flex items-start justify-between">
                    <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${styles.badge}`}>
                      {note.category}
                    </span>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteNote(note.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-2 text-slate-400 hover:text-rose-500 hover:bg-white rounded-lg transition-all"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <div>
                    <h3 className={`font-bold text-lg leading-tight mb-2 line-clamp-1 group-hover:translate-x-1 transition-transform ${styles.title}`}>{note.title}</h3>
                    <p className={`text-sm line-clamp-4 leading-relaxed ${styles.content}`}>
                      {note.content}
                    </p>
                  </div>
                  <div className={`pt-4 flex items-center justify-between border-t ${styles.footer}`}>
                    <span className="text-[10px] font-bold uppercase tracking-widest">
                      {new Date(note.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                    <div className="flex -space-x-1.5">
                      <div className="w-5 h-5 rounded-full border-2 border-white bg-indigo-500"></div>
                      <div className="w-5 h-5 rounded-full border-2 border-white bg-emerald-500"></div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function NoteModal({ note, onClose, onSave }: { note?: Note, onClose: () => void, onSave: (n: any) => void }) {
  const [formData, setFormData] = useState({
    title: note?.title || '',
    content: note?.content || '',
    category: note?.category || 'General',
    color: note?.color || 'slate'
  });

  const colors = [
    { id: 'slate', name: 'Original', bg: 'bg-slate-100' },
    { id: 'indigo', name: 'Indigo', bg: 'bg-indigo-400' },
    { id: 'rose', name: 'Rose', bg: 'bg-rose-400' },
    { id: 'amber', name: 'Amber', bg: 'bg-amber-400' },
    { id: 'emerald', name: 'Emerald', bg: 'bg-emerald-400' },
    { id: 'sky', name: 'Sky', bg: 'bg-sky-400' },
    { id: 'violet', name: 'Violet', bg: 'bg-violet-400' },
    { id: 'orange', name: 'Orange', bg: 'bg-orange-400' }
  ];

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="relative bg-white w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden border border-slate-100 flex flex-col max-h-[90vh]"
      >
        <div className="p-6 sm:p-8 space-y-6 overflow-y-auto">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-display font-bold">{note ? 'Edit Note' : 'Create New Note'}</h2>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 transition-colors"><X size={20} /></button>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Category Tag</label>
              <input 
                type="text" 
                placeholder="e.g. Physics, Personal, Exam Prep..." 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl focus:ring-2 focus:ring-indigo-500 transition-all outline-none text-slate-900"
                value={formData.category}
                onChange={e => setFormData({ ...formData, category: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Title</label>
              <input 
                type="text" 
                placeholder="What's on your mind?" 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl focus:ring-2 focus:ring-indigo-500 transition-all outline-none text-xl font-bold text-slate-900"
                value={formData.title}
                onChange={e => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Content</label>
              <textarea 
                placeholder="Start typing your notes here..." 
                rows={8}
                className="w-full px-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all outline-none resize-none text-slate-700 leading-relaxed"
                value={formData.content}
                onChange={e => setFormData({ ...formData, content: e.target.value })}
              />
            </div>

            <div className="space-y-3">
              <label className="text-sm font-bold text-slate-700">Color Variant</label>
              <div className="flex flex-wrap gap-3">
                {colors.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setFormData({ ...formData, color: c.id })}
                    className={`w-10 h-10 rounded-full border-4 transition-all ${c.bg} ${formData.color === c.id ? 'border-indigo-600 scale-110 shadow-lg' : 'border-transparent hover:scale-105'}`}
                    title={c.name}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-100 flex gap-3">
          <button 
            onClick={onClose}
            className="flex-1 py-3 text-slate-500 font-bold hover:bg-slate-200 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button 
            disabled={!formData.title || !formData.content}
            onClick={() => onSave({ ...note, ...formData })}
            className="flex-[2] py-3 bg-indigo-600 text-white font-bold rounded-xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 disabled:opacity-50 transition-all"
          >
            {note ? 'Update Note' : 'Save Note'}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

function QuizView({ subjects, onQuizComplete }: { subjects: Subject[], onQuizComplete?: () => void }) {
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [loading, setLoading] = useState(false);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>([]);
  const [currentStep, setCurrentStep] = useState<'selection' | 'quiz'>('selection');
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const generateQuiz = async (subject: Subject) => {
    setLoading(true);
    try {
      const prompt = `Generate a 5-question multiple choice quiz for the subject: "${subject.title}". 
      Context: ${subject.details}. 
      Return structured JSON data for the quiz.`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctAnswer: { type: Type.INTEGER, description: "Index of correct option (0-3)" },
                explanation: { type: Type.STRING }
              },
              required: ["question", "options", "correctAnswer", "explanation"]
            }
          }
        }
      });

      const data = JSON.parse(response.text);
      setQuizQuestions(data);
      setCurrentStep('quiz');
    } catch (error) {
      console.error("Failed to generate quiz", error);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (idx: number) => {
    if (idx === quizQuestions[currentQuestionIdx].correctAnswer) {
      setScore(prev => prev + 1);
    }
    
    if (currentQuestionIdx + 1 < quizQuestions.length) {
      setCurrentQuestionIdx(prev => prev + 1);
    } else {
      setShowResult(true);
      if (onQuizComplete) onQuizComplete();
    }
  };

  if (currentStep === 'quiz') {
    if (showResult) {
      return (
        <div className="max-w-xl mx-auto bg-white rounded-3xl p-10 text-center space-y-6 shadow-xl border border-slate-100">
          <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mx-auto">
            <Trophy className="text-indigo-600" size={40} />
          </div>
          <div>
            <h2 className="text-3xl font-display font-bold">Quiz Complete!</h2>
            <p className="text-slate-500 mt-2">You scored {score} out of {quizQuestions.length}</p>
          </div>
          <button 
            onClick={() => {
              setCurrentStep('selection');
              setShowResult(false);
              setCurrentQuestionIdx(0);
              setScore(0);
            }}
            className="w-full py-4 bg-indigo-600 text-white font-bold rounded-2xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all font-display"
          >
            Review & Continue
          </button>
        </div>
      );
    }

    const currentQ = quizQuestions[currentQuestionIdx];
    return (
      <div className="max-w-2xl mx-auto space-y-8">
        <div className="flex items-center justify-between px-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Question {currentQuestionIdx + 1} of {quizQuestions.length}</span>
          <div className="flex gap-1">
            {quizQuestions.map((_, i) => (
              <div key={i} className={`h-1.5 w-10 rounded-full ${i <= currentQuestionIdx ? 'bg-indigo-600' : 'bg-slate-200'}`}></div>
            ))}
          </div>
        </div>
        
        <div className="bg-white rounded-[32px] p-8 border border-slate-100 shadow-xl space-y-8">
          <h2 className="text-2xl font-bold leading-tight">{currentQ.question}</h2>
          <div className="grid grid-cols-1 gap-3">
            {currentQ.options.map((option, idx) => (
              <button 
                key={idx}
                onClick={() => handleAnswer(idx)}
                className="group w-full p-6 text-left bg-slate-50 border border-slate-100 rounded-2xl hover:bg-indigo-50 hover:border-indigo-200 transition-all active:scale-[0.98] flex items-center gap-4"
              >
                <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-400 group-hover:text-indigo-600 group-hover:border-indigo-200">
                  {String.fromCharCode(65 + idx)}
                </div>
                <span className="font-semibold text-slate-700 group-hover:text-indigo-700">{option}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20 lg:pb-0">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-display font-bold">Practical Quizzes</h1>
        <p className="text-slate-500 text-lg font-medium">Select a current subject to generate an AI assessment</p>
      </div>

      {!subjects.length ? (
        <div className="text-center py-20 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
          <AlertCircle className="mx-auto text-slate-300 mb-4" size={48} />
          <p className="text-slate-500 font-medium">Add a subject first to unlock AI quizzes.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {subjects.map((subject) => (
            <button 
              key={subject.id}
              onClick={() => setSelectedSubject(subject)}
              className={`group text-left bg-white p-6 rounded-[32px] border-2 transition-all active:scale-[0.98] ${
                selectedSubject?.id === subject.id 
                  ? 'border-indigo-600 ring-4 ring-indigo-50 shadow-2xl' 
                  : 'border-slate-50 hover:border-slate-100 shadow-sm'
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center text-2xl group-hover:rotate-6 transition-transform">
                  <Target size={28} />
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">{subject.category}</span>
              </div>
              <h3 className="font-bold text-xl mb-1">{subject.title}</h3>
              <p className="text-sm text-slate-500 line-clamp-2">{subject.details || 'Practice your core concepts.'}</p>
            </button>
          ))}
        </div>
      )}

      {subjects.length > 0 && (
        <div className="flex justify-center pt-8">
          <button 
            disabled={!selectedSubject || loading}
            onClick={() => selectedSubject && generateQuiz(selectedSubject)}
            className="group relative flex items-center gap-3 px-10 py-5 bg-indigo-600 text-white rounded-3xl font-bold text-lg shadow-2xl shadow-indigo-200 hover:bg-indigo-700 hover:scale-105 disabled:opacity-50 disabled:scale-100 transition-all overflow-hidden"
          >
            {loading ? <Loader2 className="animate-spin" size={24} /> : <BrainCircuit size={24} />}
            <span>{loading ? 'Curating Questions...' : 'Start Practical Quiz'}</span>
          </button>
        </div>
      )}
    </div>
  );
}

function TheoryView({ subjects, onTheoryComplete }: { subjects: Subject[], onTheoryComplete?: () => void }) {
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [loading, setLoading] = useState(false);
  const [explanation, setExplanation] = useState<{ title: string, content: string, examples: string[] } | null>(null);

  const generateTheory = async (subject: Subject) => {
    setLoading(true);
    setExplanation(null);
    try {
      const prompt = `Explain the core theory of "${subject.title}" in a simplified way for a student. 
      Context: ${subject.details}. 
      Focus on basic concepts and practical applications.`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              content: { type: Type.STRING },
              examples: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["title", "content", "examples"]
          }
        }
      });

      const data = JSON.parse(response.text);
      setExplanation(data);
      if (onTheoryComplete) onTheoryComplete();
    } catch (error) {
      console.error("Theory generation failed", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10 pb-20 lg:pb-0">
      <div className="bg-indigo-600 rounded-[40px] p-8 lg:p-14 text-white relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-6">
          <h1 className="text-4xl lg:text-5xl font-display font-bold leading-tight">Master Theories</h1>
          <p className="text-indigo-100 text-lg opacity-90 leading-relaxed">Turn your complex subjects into easy-to-understand stories.</p>
          
          <div className="flex flex-wrap gap-4 pt-4">
            {subjects.map(s => (
              <button 
                key={s.id}
                onClick={() => setSelectedSubject(s)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                  selectedSubject?.id === s.id 
                    ? 'bg-white text-indigo-600 shadow-xl scale-105' 
                    : 'bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                {s.title}
              </button>
            ))}
          </div>

          <button 
            disabled={!selectedSubject || loading}
            onClick={() => selectedSubject && generateTheory(selectedSubject)}
            className="px-8 py-4 bg-white text-indigo-600 rounded-2xl font-bold hover:bg-indigo-50 disabled:opacity-50 transition-all flex items-center gap-2 shadow-xl shadow-indigo-900/20"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : <BookOpen size={20} />}
            {loading ? 'Simplifying...' : 'Summarize Concept'}
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {explanation && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-8"
          >
            <div className="lg:col-span-2 space-y-8">
              <div className="bg-white p-8 sm:p-12 rounded-[40px] border border-slate-100 shadow-xl space-y-8">
                <h2 className="text-3xl font-display font-bold text-slate-900 underline decoration-indigo-200 decoration-8 underline-offset-[-2px]">{explanation.title}</h2>
                <p className="text-lg text-slate-600 leading-relaxed whitespace-pre-wrap">{explanation.content}</p>
                
                <div className="pt-8 border-t border-slate-50">
                  <h4 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Practical Examples</h4>
                  <div className="grid grid-cols-1 gap-4">
                    {explanation.examples.map((ex, i) => (
                      <div key={i} className="flex items-start gap-4 p-6 bg-slate-50 rounded-3xl border border-slate-100 border-l-4 border-l-indigo-600">
                        <p className="text-slate-700 font-medium italic leading-relaxed">"{ex}"</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-indigo-50 border border-indigo-100 p-8 rounded-[40px] space-y-6">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-indigo-600 shadow-sm">
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-indigo-900 font-display">Key Takeaway</h3>
                  <p className="text-indigo-700/80 mt-2 text-sm leading-relaxed">Focus on the core mechanics rather than the formulas. Understanding the "Why" makes the "How" obvious.</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SettingsView({ profile, setProfile, settings, setSettings }: { 
  profile: UserProfile, 
  setProfile: (p: UserProfile) => void,
  settings: AppSettings,
  setSettings: (s: AppSettings) => void
}) {
  const [localProfile, setLocalProfile] = useState(profile);
  const [localSettings, setLocalSettings] = useState(settings);
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'app'>('profile');

  const saveSettings = () => {
    setProfile(localProfile);
    setSettings(localSettings);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20 lg:pb-0">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold">Settings</h1>
          <p className="text-slate-500">Manage your account and app preferences</p>
        </div>
        <button 
          onClick={saveSettings}
          className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
        >
          Save Changes
        </button>
      </div>

      <div className="flex gap-1 bg-slate-100 p-1 rounded-2xl w-fit">
        <button 
          onClick={() => setActiveSubTab('profile')}
          className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeSubTab === 'profile' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
        >
          Profile
        </button>
        <button 
          onClick={() => setActiveSubTab('app')}
          className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeSubTab === 'app' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
        >
          App Preferences
        </button>
      </div>

      <div className="grid grid-cols-1 gap-8">
        {activeSubTab === 'profile' ? (
          <>
            {/* Personal Info */}
            <section className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                  <User size={20} />
                </div>
                <h3 className="text-xl font-bold">Personal Information</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Display Name</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500"
                    value={localProfile.name}
                    onChange={e => setLocalProfile({ ...localProfile, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Username</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">@</span>
                    <input 
                      type="text" 
                      className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500"
                      value={localProfile.username}
                      onChange={e => setLocalProfile({ ...localProfile, username: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-bold text-slate-700">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="email" 
                      className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500"
                      value={localProfile.email}
                      onChange={e => setLocalProfile({ ...localProfile, email: e.target.value })}
                    />
                  </div>
                </div>
              </div>
            </section>

            {/* Login & Security */}
            <section className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                  <ShieldCheck size={20} />
                </div>
                <h3 className="text-xl font-bold">Login & Security</h3>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border">
                  <div>
                    <p className="font-bold">Two-Factor Authentication</p>
                    <p className="text-xs text-slate-500">Secure your account with an extra layer of protection.</p>
                  </div>
                  <div className="w-12 h-6 bg-slate-200 rounded-full cursor-pointer relative">
                    <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                  </div>
                </div>
                <button className="text-indigo-600 font-bold text-sm px-4">Change Password</button>
              </div>
            </section>
          </>
        ) : (
          <>
            {/* App Experience Settings */}
            <section className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm space-y-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                  <Zap size={20} />
                </div>
                <h3 className="text-xl font-bold">Experience & AI</h3>
              </div>

              <div className="space-y-6">
                {/* AI Model */}
                <div className="space-y-3">
                  <label className="flex items-center gap-2 text-sm font-bold text-slate-700">
                    <Cpu size={16} />
                    AI Model Version
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {['Gemini 1.5', 'Gemini 2.0', 'Experimental'].map((v) => (
                      <button 
                        key={v}
                        onClick={() => setLocalSettings({ ...localSettings, aiModel: v as any })}
                        className={`py-3 px-4 rounded-xl text-xs font-bold border-2 transition-all ${localSettings.aiModel === v ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-slate-100 text-slate-500 hover:bg-slate-50'}`}
                      >
                        {v}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Difficulty */}
                <div className="space-y-3">
                  <label className="flex items-center gap-2 text-sm font-bold text-slate-700">
                    <Trophy size={16} />
                    Default Learning Difficulty
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {['Beginner', 'Intermediate', 'Advanced'].map((d) => (
                      <button 
                        key={d}
                        onClick={() => setLocalSettings({ ...localSettings, difficulty: d as any })}
                        className={`py-3 px-4 rounded-xl text-xs font-bold border-2 transition-all ${localSettings.difficulty === d ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-slate-100 text-slate-500 hover:bg-slate-50'}`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            {/* Application Preferences */}
            <section className="bg-white p-8 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">
                  <Globe size={20} />
                </div>
                <h3 className="text-xl font-bold">App Preferences</h3>
              </div>

              <div className="space-y-4">
                {/* Study Reminders */}
                <div className="flex items-center justify-between p-5 bg-slate-50 rounded-2xl border">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-slate-400 shadow-sm border">
                      <Calendar size={20} />
                    </div>
                    <div>
                      <p className="font-bold">Study Reminders</p>
                      <p className="text-xs text-slate-500">Daily nudges to keep your streak alive.</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setLocalSettings({ ...localSettings, studyReminders: !localSettings.studyReminders })}
                    className={`w-14 h-8 rounded-full transition-all relative ${localSettings.studyReminders ? 'bg-indigo-600' : 'bg-slate-200'}`}
                  >
                    <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all shadow-sm ${localSettings.studyReminders ? 'left-7' : 'left-1'}`}></div>
                  </button>
                </div>
              </div>
            </section>
          </>
        )}
      </div>
    </div>
  );
}
